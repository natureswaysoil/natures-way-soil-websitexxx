import Stripe from 'stripe';
import { NextResponse } from 'next/server';

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const lineItems = (body?.lineItems || []).map((item: any) => ({
      price_data: {
        currency: 'usd',
        product_data: { name: item.name },
        unit_amount: item.amount,
      },
      quantity: item.quantity || 1,
      adjustable_quantity: { enabled: true, minimum: 1 },
    }));

    const secret = process.env.STRIPE_SECRET_KEY || '';
    if (!secret) {
      throw new Error('Missing STRIPE_SECRET_KEY');
    }
    const stripe = new Stripe(secret, { apiVersion: '2024-06-20' });

    const session = await stripe.checkout.sessions.create({
      mode: 'payment',
      payment_method_types: ['card'],
      line_items: lineItems,
      success_url: process.env.NEXT_PUBLIC_STRIPE_SUCCESS_URL || 'http://localhost:3000/success',
      cancel_url: process.env.NEXT_PUBLIC_STRIPE_CANCEL_URL || 'http://localhost:3000/cancel',
    });

    return NextResponse.json({ id: session.id, url: session.url });
  } catch (e: any) {
    return NextResponse.json({ error: e?.message || 'Unknown error' }, { status: 500 });
  }
}
