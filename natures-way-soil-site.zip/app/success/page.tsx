import Link from 'next/link';
import { Container } from '@/components/Container';

export default function SuccessPage() {
  return (
    <Container className="py-16 text-center">
      <h1 className="text-3xl font-semibold">Payment Successful 🎉</h1>
      <p className="mt-3 text-stone-700">Thank you for your order! A confirmation email is on its way.</p>
      <Link href="/products" className="mt-6 inline-block underline">Continue Shopping</Link>
    </Container>
  );
}
