import { Container } from '@/components/Container';
import { getProductBySlug } from '@/lib/products';
import Link from 'next/link';
import { redirect } from 'next/navigation';

export async function generateStaticParams() {
  const { PRODUCTS } = await import('@/lib/products');
  return PRODUCTS.map((p) => ({ slug: p.slug }));
}

export default async function ProductPage({ params }: { params: { slug: string } }) {
  const product = getProductBySlug(params.slug);
  if (!product) {
    return (
      <Container className="py-16">
        <h1 className="text-2xl font-semibold">Product not found</h1>
        <Link className="underline mt-4 inline-block" href="/products">Back to products</Link>
      </Container>
    );
  }

  const provider = process.env.NEXT_PUBLIC_CHECKOUT_PROVIDER || 'links';

  async function handleBuy() {
    'use server';
    if (provider !== 'stripe') return;
    const res = await fetch(`${process.env.NEXT_PUBLIC_BASE_URL || ''}/api/checkout/session`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        lineItems: [{
          name: product.title,
          amount: product.price,
          quantity: 1,
        }],
      }),
    });
    if (!res.ok) throw new Error('Checkout failed');
    const data = await res.json();
    return data.url as string;
  }

  return (
    <Container className="py-12">
      <div className="grid lg:grid-cols-2 gap-10">
        <div className="rounded-2xl bg-white shadow p-4 aspect-square flex items-center justify-center overflow-hidden">
          {product.imageUrl ? (
            // Using a plain img to avoid remote config for next/image
            // eslint-disable-next-line @next/next/no-img-element
            <img src={product.imageUrl} alt={product.title} className="w-full h-full object-cover rounded-xl" />
          ) : (
            <div className="text-6xl">{product.emoji || '🌿'}</div>
          )}
        </div>
        <div>
          <h1 className="text-3xl font-semibold">{product.title}</h1>
          <p className="mt-2 text-stone-600">{product.subtitle}</p>
          <p className="mt-3 text-2xl font-bold">
            {(product.price/100).toLocaleString('en-US', { style: 'currency', currency: 'USD' })}
          </p>
          <p className="mt-4 leading-relaxed text-stone-800">{product.description}</p>

          <div className="mt-8 flex flex-wrap gap-3">
            {provider === 'stripe' ? (
              <form action={async () => {
                const url = await handleBuy();
                if (url) {
                  // @ts-ignore
                  redirect(url);
                }
              }}>
                <button type="submit" className="px-6 py-3 rounded-xl bg-green-700 text-white hover:bg-green-800">Buy Now</button>
              </form>
            ) : (
              <>
                {product.amazonUrl && (
                  <a href={product.amazonUrl} target="_blank" className="px-5 py-3 rounded-xl bg-black text-white hover:opacity-90" rel="noreferrer">
                    Buy on Amazon
                  </a>
                )}
                {product.walmartUrl && (
                  <a href={product.walmartUrl} target="_blank" className="px-5 py-3 rounded-xl bg-blue-700 text-white hover:opacity-90" rel="noreferrer">
                    Buy on Walmart
                  </a>
                )}
              </>
            )}
            <Link href="/products" className="px-5 py-3 rounded-xl border border-stone-300 hover:bg-white">Back</Link>
          </div>

          <p className="mt-6 text-sm text-stone-600">Also available on Amazon and Walmart.com — see above.</p>
        </div>
      </div>
    </Container>
  );
}
