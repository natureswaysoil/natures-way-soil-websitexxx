import { Container } from '@/components/Container';
import { PRODUCTS } from '@/lib/products';
import { ProductCard } from '@/components/ProductCard';

export const metadata = { title: "Products — Nature's Way Soil" };

export default function ProductsPage() {
  return (
    <Container className="py-12">
      <h1 className="text-3xl font-semibold">Products</h1>
      <p className="mt-2 text-stone-600">Organic fertilizers, lawn care, and soil builders.</p>
      <div className="mt-8 grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {PRODUCTS.map((p) => (
          <ProductCard key={p.id} product={p} />
        ))}
      </div>
    </Container>
  );
}
