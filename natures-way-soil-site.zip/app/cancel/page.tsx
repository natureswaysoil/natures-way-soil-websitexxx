import Link from 'next/link';
import { Container } from '@/components/Container';

export default function CancelPage() {
  return (
    <Container className="py-16 text-center">
      <h1 className="text-3xl font-semibold">Payment Canceled</h1>
      <p className="mt-3 text-stone-700">No worries—your cart is still available if you change your mind.</p>
      <Link href="/products" className="mt-6 inline-block underline">Back to Products</Link>
    </Container>
  );
}
