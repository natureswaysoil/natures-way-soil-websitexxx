import Link from 'next/link';

export default function NotFound() {
  return (
    <div className="min-h-[60vh] flex flex-col items-center justify-center text-center p-8">
      <h1 className="text-4xl font-bold">Page Not Found</h1>
      <p className="mt-2 text-stone-600">The page you’re looking for doesn’t exist.</p>
      <Link href="/" className="mt-6 underline">Go home</Link>
    </div>
  );
}
