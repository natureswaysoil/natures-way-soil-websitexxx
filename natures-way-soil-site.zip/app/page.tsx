import Link from 'next/link';
import { Container } from '@/components/Container';

export default function HomePage() {
  return (
    <>
      <section className="bg-gradient-to-b from-green-100 to-stone-50 py-16">
        <Container>
          <div className="grid md:grid-cols-2 gap-10 items-center">
            <div>
              <h1 className="text-4xl md:text-5xl font-bold leading-tight">Adding Life Back to the Soil</h1>
              <p className="mt-4 text-lg text-stone-700">
                Family‑run makers of organic fertilizers, biochar, compost, and pet‑safe lawn care.
                Safe for kids, pets, and pollinators.
              </p>
              <div className="mt-8 flex gap-4">
                <Link href="/products" className="px-6 py-3 rounded-xl bg-green-700 text-white hover:bg-green-800 transition">Shop Products</Link>
                <a href="#about" className="px-6 py-3 rounded-xl border border-stone-300 hover:bg-white transition">Learn More</a>
              </div>
              <p className="mt-6 text-sm text-stone-600">Also available on Amazon and Walmart.com — details on each product page.</p>
            </div>
            <div className="aspect-video rounded-2xl bg-white/70 shadow p-4 flex items-center justify-center text-center">
              <div>
                <div className="text-7xl">🌱</div>
                <p className="mt-3 text-stone-600">Healthy soils, stronger roots, greener lawns.</p>
              </div>
            </div>
          </div>
        </Container>
      </section>

      <section id="about" className="py-16">
        <Container>
          <div className="grid md:grid-cols-2 gap-10 items-start">
            <div>
              <h2 className="text-3xl font-semibold">Our Story</h2>
              <p className="mt-4 leading-relaxed text-stone-700">
                We’re a small family farm that switched from synthetics to living soils.
                We craft microbially active products—worm castings, activated biochar, kelp, and BM‑1—to bring soil back to life.
              </p>
              <p className="mt-3 leading-relaxed text-stone-700">
                Products are kid‑, pet‑, and bee‑friendly. We use duckweed extracts, sea minerals, and humates to feed both plants and soil biology.
              </p>
              <div className="mt-6">
                <Link href="/products" className="underline underline-offset-4">Browse all products →</Link>
              </div>
            </div>
            <div className="rounded-2xl bg-white shadow p-6">
              <ul className="space-y-3 text-stone-800">
                <li>✔️ Safe for children, pets, and beneficial insects</li>
                <li>✔️ Microbially active formulas (BM‑1, humic/fulvic, kelp)</li>
                <li>✔️ Activated biochar for nutrient retention</li>
                <li>✔️ Transparent labels and real results</li>
              </ul>
            </div>
          </div>
        </Container>
      </section>
    </>
  );
}
