export function Footer() {
  return (
    <footer className="border-t border-stone-200 bg-white">
      <div className="mx-auto max-w-6xl px-4 py-10 text-sm text-stone-600">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div>
            <div className="font-semibold text-stone-800">Nature&apos;s Way Soil</div>
            <div className="mt-1">Also available on Amazon and Walmart.com</div>
          </div>
          <div className="opacity-80">© {new Date().getFullYear()} Nature&apos;s Way Soil — All rights reserved.</div>
        </div>
      </div>
    </footer>
  );
}
