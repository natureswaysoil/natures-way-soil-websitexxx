import Link from 'next/link';
import { Product } from '@/lib/products';

export function ProductCard({ product }: { product: Product }) {
  return (
    <div className="rounded-2xl bg-white shadow border border-stone-200 p-4 flex flex-col">
      <div className="aspect-square rounded-xl bg-stone-50 flex items-center justify-center overflow-hidden">
        {product.imageUrl ? (
          // eslint-disable-next-line @next/next/no-img-element
          <img src={product.imageUrl} alt={product.title} className="w-full h-full object-cover rounded-xl" />
        ) : (
          <div className="text-5xl">{product.emoji || '🌿'}</div>
        )}
      </div>
      <div className="mt-4">
        <h3 className="font-semibold line-clamp-2 min-h-[3.25rem]">{product.title}</h3>
        <p className="text-sm text-stone-600 mt-1 line-clamp-2 min-h-[2.25rem]">{product.subtitle}</p>
      </div>
      <div className="mt-4 flex items-center justify-between">
        <div className="font-semibold">
          {(product.price/100).toLocaleString('en-US', { style: 'currency', currency: 'USD' })}
        </div>
        <Link href={`/products/${product.slug}`} className="text-sm underline">View</Link>
      </div>
    </div>
  );
}
