import Link from 'next/link';

export function Header() {
  return (
    <header className="sticky top-0 z-40 bg-white/90 backdrop-blur border-b border-stone-200">
      <div className="mx-auto max-w-6xl px-4 h-16 flex items-center justify-between">
        <Link href="/" className="font-semibold">Nature&apos;s Way Soil</Link>
        <nav className="flex items-center gap-6 text-sm">
          <Link href="/products" className="hover:underline">Products</Link>
          <a href="/#about" className="hover:underline">About</a>
          <a href="mailto:info@natureswaysoil.com" className="hover:underline">Contact</a>
        </nav>
      </div>
    </header>
  );
}
