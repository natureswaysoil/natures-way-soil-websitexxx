/**
 * Usage: node scripts/csv_to_products.mjs catalog.csv
 * CSV headers expected:
 * id,title,subtitle,description,price,emoji,imageUrl,slug,amazonUrl,walmartUrl
 * - price: in dollars (e.g., 29.99) OR cents (e.g., 2999). Script auto-detects.
 */
import fs from 'node:fs';
import path from 'node:path';
import { parse } from 'csv-parse';

const input = process.argv[2];
if (!input) {
  console.error('Please provide a CSV path, e.g., node scripts/csv_to_products.mjs catalog.csv');
  process.exit(1);
}

const csvPath = path.resolve(process.cwd(), input);
if (!fs.existsSync(csvPath)) {
  console.error('CSV not found at', csvPath);
  process.exit(1);
}

function slugify(input) {
  return (input || 'product')
    .toLowerCase()
    .replace(/[^a-z0-9\s-]/g, '')
    .trim()
    .replace(/\s+/g, '-')
    .replace(/-+/g, '-');
}

function toCents(v) {
  if (v === undefined || v === null || String(v).trim() === '') return 0;
  const num = Number(v);
  if (Number.isNaN(num)) return 0;
  // If it's > 1000 and has no decimal, assume cents already
  if (Number.isInteger(num) && num >= 1000) return num;
  // Otherwise assume dollars
  return Math.round(num * 100);
}

const rows = [];
fs.createReadStream(csvPath)
  .pipe(parse({ columns: true, skip_empty_lines: true, trim: true }))
  .on('data', (rec) => rows.push(rec))
  .on('end', () => {
    if (!rows.length) {
      console.error('CSV is empty or headers missing.');
      process.exit(1);
    }

    // Map to TS objects
    const products = rows.map((r) => {
      const title = r.title || 'Untitled';
      const slug = r.slug && r.slug.trim() ? r.slug : slugify(title);
      const id = r.id && r.id.trim() ? r.id : slug;
      const price = toCents(r.price);
      return {
        id,
        slug,
        title,
        subtitle: r.subtitle || '',
        description: r.description || '',
        price,
        emoji: r.emoji || '',
        imageUrl: r.imageUrl || '',
        amazonUrl: r.amazonUrl || '',
        walmartUrl: r.walmartUrl || '',
      };
    });

    // Deduplicate IDs
    const used = new Map();
    products.forEach((p) => {
      if (!used.has(p.id)) { used.set(p.id, 1); return; }
      const count = used.get(p.id) + 1;
      used.set(p.id, count);
      p.id = `${p.id}-${count}`;
    });

    const outPath = path.resolve(process.cwd(), 'lib', 'products.ts');
    const ts = `export type Product = {
  id: string;
  slug: string;
  title: string;
  subtitle?: string;
  description: string;
  price: number; // cents
  emoji?: string;
  imageUrl?: string;
  amazonUrl?: string;
  walmartUrl?: string;
};

export const PRODUCTS: Product[] = ${JSON.stringify(products, null, 2)};

export function getProductBySlug(slug: string) {
  return PRODUCTS.find((p) => p.slug === slug);
}
`;
    fs.writeFileSync(outPath, ts, 'utf-8');
    console.log('Wrote', outPath, 'with', products.length, 'products.');
  })
  .on('error', (err) => {
    console.error('CSV parse error:', err.message);
    process.exit(1);
  });
