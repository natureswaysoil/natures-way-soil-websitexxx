export type Product = {
  id: string;
  slug: string;
  title: string;
  subtitle?: string;
  description: string;
  price: number; // cents
  emoji?: string;
  imageUrl?: string; // optional remote or local path
  amazonUrl?: string;
  walmartUrl?: string;
};

export const PRODUCTS: Product[] = [
  {
    id: 'dog-urine-1g',
    slug: 'dog-urine-neutralizer-1-gallon',
    title: "Dog Urine Neutralizer & Lawn Revitalizer — 1 Gallon",
    subtitle: 'Pet‑safe grass repair for yellow spots; odor eliminator & soil reviver',
    description: 'Bio‑enzymatic, pet‑safe formula that neutralizes urine salts and helps lawns recover. Safe for kids, pets, and pollinators.',
    price: 4999,
    emoji: '🐶',
    amazonUrl: 'https://www.amazon.com/',
    walmartUrl: 'https://www.walmart.com/',
  },
  {
    id: 'bone-meal-32oz',
    slug: 'liquid-bone-meal-32-oz',
    title: 'Liquid Bone Meal Fertilizer — 32 oz (2‑14‑0)',
    subtitle: 'Fast‑absorbing phosphorus & calcium for roots, flowers & fruits',
    description: 'Microbially friendly liquid bone meal with humic/fulvic support for strong roots and blooms. Ideal for vegetables, flowers, trees, and shrubs.',
    price: 2999,
    emoji: '🦴',
    amazonUrl: 'https://www.amazon.com/',
  },
  {
    id: 'kelp-1g',
    slug: 'liquid-kelp-1-gallon',
    title: 'Liquid Organic Kelp — 1 Gallon',
    subtitle: 'Natural growth support with micronutrients & hormones',
    description: 'Cold‑processed kelp concentrate to enhance root development, stress tolerance, and nutrient uptake.',
    price: 3999,
    emoji: '🌊',
    amazonUrl: 'https://www.amazon.com/',
  },
  {
    id: 'hay-pasture-1g',
    slug: 'hay-and-pasture-1-gallon',
    title: 'Hay & Pasture Liquid Fertilizer — 1 Gallon',
    subtitle: 'Livestock‑safe nutrient blend for forage health',
    description: 'Balanced NPK with humates, kelp, and sea minerals formulated for safe use around horses and livestock.',
    price: 5499,
    emoji: '🐴',
    amazonUrl: 'https://www.amazon.com/',
  },
  {
    id: 'biochar-humates-1g',
    slug: 'liquid-biochar-with-humates-1-gallon',
    title: 'Liquid Biochar with Humates — 1 Gallon',
    subtitle: 'Activated biochar suspension to retain nutrients & water',
    description: 'Biochar + humic/fulvic acids to boost CEC, soil structure, and microbial habitat for resilient growth.',
    price: 4499,
    emoji: '🔥',
    amazonUrl: 'https://www.amazon.com/',
  },
];

export function getProductBySlug(slug: string) {
  return PRODUCTS.find((p) => p.slug === slug);
}
